#R code
purl("Conditioning_FLBEIA.Rmd", output = "Conditioning_FLBEIA.R")
